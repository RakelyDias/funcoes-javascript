function multiplicacao(numero1, numero2) {
  return numero1 * numero2;
}

let multiplicacao1 = multiplicacao(6, 7);
let multiplicacao2 = multiplicacao(9, 10);
let multiplicacao3 = multiplicacao(12, 25);

console.log(multiplicacao1);
console.log(multiplicacao2);
console.log(multiplicacao3);