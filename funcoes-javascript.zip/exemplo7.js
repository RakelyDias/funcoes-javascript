let numero = 10;
const button = document.querySelector("button");

button.addEventListener("click", () => {
  numero++;
  console.log(numero);
});

console.log(numero);