function somar(valorA, valorB) {
  alert(valorA + valorB);
}
somar(20, 12);