let somar = (valor1, valor2) => valor1 + valor2;
let multiplicar = (numero1, numero2) => numero1 * numero2;

console.log(somar(10, 70));
console.log(multiplicar(5, 4));