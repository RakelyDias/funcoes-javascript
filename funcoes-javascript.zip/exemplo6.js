let numero = 10;
const button = document.querySelector("button");

button.addEventListener("click", function () {
  numero++;
  console.log(numero);
});