function mostrarAlerta() {
  let nome = "Marcio";
  alert("Seja bem-vindo(a), " + nome);
}
mostrarAlerta();