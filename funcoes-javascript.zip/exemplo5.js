function parOuImpar(numero) {
  if (numero % 2 === 0) {
    return "PAR";
  } else {
    return "IMPAR";
  }
}

console.log(parOuImpar(14));